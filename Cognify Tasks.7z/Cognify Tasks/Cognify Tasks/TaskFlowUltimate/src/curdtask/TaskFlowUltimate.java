package curdtask;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

class Task {
    int id;
    String title;
    String description;
    String category;
    String priority;
    String status;
    LocalDate dueDate;

    Task(int id, String title, String description, String category,
         String priority, LocalDate dueDate) {

        this.id = id;
        this.title = title;
        this.description = description;
        this.category = category;
        this.priority = priority;
        this.status = "Pending";
        this.dueDate = dueDate;
    }

    @Override
    public String toString() {
        return id + "," + title + "," + description + "," +
               category + "," + priority + "," + status + "," + dueDate;
    }
}

public class TaskFlowUltimate {

    static List<Task> tasks = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);
    static int taskCounter = 1;

    static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    static String file = "taskflow_data.txt";

    public static void main(String[] args) {

        loadFromFile();

        while (true) {
            System.out.println("\n===== TASKFLOW ULTIMATE =====");
            System.out.println("1. Create Task");
            System.out.println("2. View Tasks");
            System.out.println("3. Update Task");
            System.out.println("4. Delete Task");
            System.out.println("5. Search Task");
            System.out.println("6. Filter Tasks");
            System.out.println("7. Mark Completed");
            System.out.println("8. Dashboard");
            System.out.println("9. Exit");

            System.out.print("Enter choice: ");
            int ch = getIntInput();

            switch (ch) {
                case 1 -> createTask();
                case 2 -> viewTasks();
                case 3 -> updateTask();
                case 4 -> deleteTask();
                case 5 -> searchTask();
                case 6 -> filterTasks();
                case 7 -> markCompleted();
                case 8 -> dashboard();
                case 9 -> {
                    saveToFile();
                    System.out.println("Data Saved. Exiting...");
                    return;
                }
                default -> System.out.println("Invalid Choice");
            }
        }
    }

    static int getIntInput() {
        while (true) {
            try {
                return Integer.parseInt(sc.nextLine());
            } catch (Exception e) {
                System.out.print("Enter valid number: ");
            }
        }
    }

    static LocalDate getDate() {
        while (true) {
            try {
                String d = sc.nextLine();
                return LocalDate.parse(d, formatter);
            } catch (DateTimeParseException e) {
                System.out.print("Invalid Date! Use dd-MM-yyyy: ");
            }
        }
    }

    static void createTask() {

        System.out.print("Enter Title: ");
        String title = sc.nextLine();

        System.out.print("Enter Description: ");
        String desc = sc.nextLine();

        System.out.print("Enter Category: ");
        String cat = sc.nextLine();

        System.out.print("Enter Priority (High/Medium/Low): ");
        String pri = sc.nextLine();

        System.out.print("Enter Due Date (dd-MM-yyyy): ");
        LocalDate date = getDate();

        tasks.add(new Task(taskCounter++, title, desc, cat, pri, date));

        saveToFile();

        System.out.println("Task Added Successfully");
    }

    static void viewTasks() {
        if (tasks.isEmpty()) {
            System.out.println("No Tasks Available");
            return;
        }

        for (Task t : tasks) {
            System.out.println(t.id + " | " + t.title + " | " +
                    t.priority + " | " + t.status);
        }
    }

    static Task findById(int id) {
        for (Task t : tasks)
            if (t.id == id) return t;

        return null;
    }

    static void updateTask() {
        System.out.print("Enter ID: ");
        int id = getIntInput();

        Task t = findById(id);

        if (t == null) {
            System.out.println("Not Found");
            return;
        }

        System.out.print("New Title: ");
        t.title = sc.nextLine();

        System.out.print("New Priority: ");
        t.priority = sc.nextLine();

        saveToFile();

        System.out.println("Updated");
    }

    static void deleteTask() {
        System.out.print("Enter ID: ");
        int id = getIntInput();

        boolean r = tasks.removeIf(x -> x.id == id);

        if (r) {
            saveToFile();
            System.out.println("Deleted");
        } else System.out.println("Not Found");
    }

    static void searchTask() {
        System.out.print("Search title: ");
        String k = sc.nextLine();

        for (Task t : tasks)
            if (t.title.toLowerCase().contains(k.toLowerCase()))
                System.out.println(t.title + " | " + t.status);
    }

    static void filterTasks() {
        System.out.print("Priority: ");
        String p = sc.nextLine();

        for (Task t : tasks)
            if (t.priority.equalsIgnoreCase(p))
                System.out.println(t.title);
    }

    static void markCompleted() {
        System.out.print("Enter ID: ");
        int id = getIntInput();

        Task t = findById(id);

        if (t != null) {
            t.status = "Completed";
            saveToFile();
            System.out.println("Marked Completed");
        } else System.out.println("Not Found");
    }

    static void dashboard() {

        int total = tasks.size();
        int pending = 0, completed = 0;

        for (Task t : tasks) {
            if (t.status.equals("Pending")) pending++;
            if (t.status.equals("Completed")) completed++;
        }

        System.out.println("\n--- DASHBOARD ---");
        System.out.println("Total: " + total);
        System.out.println("Pending: " + pending);
        System.out.println("Completed: " + completed);
    }

    static void saveToFile() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {

            for (Task t : tasks) {
                bw.write(t.toString());
                bw.newLine();
            }

        } catch (IOException e) {
            System.out.println("Save Error: " + e.getMessage());
        }
    }

    static void loadFromFile() {
        try {
            File f = new File(file);
            if (!f.exists()) return;

            BufferedReader br = new BufferedReader(new FileReader(f));

            String line;
            while ((line = br.readLine()) != null) {
                String[] d = line.split(",");

                Task t = new Task(
                        Integer.parseInt(d[0]),
                        d[1], d[2], d[3], d[4],
                        LocalDate.parse(d[6])
                );

                t.status = d[5];

                tasks.add(t);
            }

            if (!tasks.isEmpty())
                taskCounter = tasks.get(tasks.size() - 1).id + 1;

        } catch (Exception e) {
            System.out.println("Load Error: " + e.getMessage());
        }
    }
}

