package Temperature;

import java.util.Scanner;

public class TempFlow {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- TempFlow: Temperature Converter ---");
            System.out.println("1. Celsius → Fahrenheit");
            System.out.println("2. Celsius → Kelvin");
            System.out.println("3. Fahrenheit → Celsius");
            System.out.println("4. Fahrenheit → Kelvin");
            System.out.println("5. Kelvin → Celsius");
            System.out.println("6. Kelvin → Fahrenheit");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");

            int choice = getIntInput(sc);

            if (choice == 7) {
                System.out.println("Exiting TempFlow. Goodbye!");
                break;
            }

            System.out.print("Enter temperature: ");
            double temp = getDoubleInput(sc);

            switch (choice) {
                case 1: System.out.printf("%.2f °C = %.2f °F\n", temp, cToF(temp)); break;
                case 2: System.out.printf("%.2f °C = %.2f K\n", temp, cToK(temp)); break;
                case 3: System.out.printf("%.2f °F = %.2f °C\n", temp, fToC(temp)); break;
                case 4: System.out.printf("%.2f °F = %.2f K\n", temp, fToK(temp)); break;
                case 5: System.out.printf("%.2f K = %.2f °C\n", temp, kToC(temp)); break;
                case 6: System.out.printf("%.2f K = %.2f °F\n", temp, kToF(temp)); break;
                default: System.out.println("Invalid choice. Try again.");
            }
        }
        sc.close();
    }

    // --- Conversion Methods ---
    public static double cToF(double c) { return (c * 9 / 5) + 32; }
    public static double cToK(double c) { return c + 273.15; }
    public static double fToC(double f) { return (f - 32) * 5 / 9; }
    public static double fToK(double f) { return (f - 32) * 5 / 9 + 273.15; }
    public static double kToC(double k) { return k - 273.15; }
    public static double kToF(double k) { return (k - 273.15) * 9 / 5 + 32; }

    // --- Input Validation ---
    private static int getIntInput(Scanner sc) {
        while (true) {
            try {
                return Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Invalid input. Enter a number: ");
            }
        }
    }

    private static double getDoubleInput(Scanner sc) {
        while (true) {
            try {
                return Double.parseDouble(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Invalid temperature. Enter a valid number: ");
            }
        }
    }
}