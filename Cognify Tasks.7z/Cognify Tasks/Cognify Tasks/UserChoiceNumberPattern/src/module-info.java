/**
 * 
 */
/**
 * 
 */
module UserChoiceNumberPattern {
}