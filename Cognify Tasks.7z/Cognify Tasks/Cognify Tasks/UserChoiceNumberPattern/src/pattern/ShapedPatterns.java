package pattern;

import java.util.Scanner;

public class ShapedPatterns {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Choose Shape:");
        System.out.println("1. Butterfly");
        System.out.println("2. Heart");
        System.out.println("3. Diamond");
        System.out.println("4. Circle");
        System.out.println("5. Square");
        System.out.println("6. Triangle");
        System.out.println("7. Rectangle");
        System.out.println("8. Hexagon");
        System.out.print("Enter choice: ");
        int shape = sc.nextInt();

        System.out.println("\nChoose Output Type:");
        System.out.println("1. Symbols");
        System.out.println("2. Numbers");
        System.out.print("Enter choice: ");
        int type = sc.nextInt();

        char symbol = '~';
        if (type == 1) {
            System.out.println("Choose Symbol: 1.!  2.@  3.#  4.$  5.%  6.^  7.&  8.* ");
            symbol = getSymbol(sc.nextInt());
        }

        switch (shape) {
            case 1: butterfly(5, type, symbol); break;
            case 2: heart(7, type, symbol); break;
            case 3: diamond(5, type, symbol); break;
            case 4: circle(6, type, symbol); break;
            case 5: square(5, type, symbol); break;
            case 6: triangle(5, type, symbol); break;
            case 7: rectangle(4, 9, type, symbol); break;
            case 8: hexagon(4, type, symbol); break;
            default: System.out.println("Invalid choice");
        }

        sc.close();
    }

    static void print(int type, int num, char symbol) {
        if (type == 1)
            System.out.print(symbol);
        else
            System.out.print(num % 10);
    }

    static char getSymbol(int c) {
        switch (c) {
            case 1: return '!';
            case 2: return '@';
            case 3: return '#';
            case 4: return '$';
            case 5: return '%';
            case 6: return '^';
            case 7: return '&';
            case 8: return '*';
            default: return '~';
        }
    }

    // ===== BUTTERFLY =====
    static void butterfly(int n, int type, char symbol) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) print(type, j, symbol);
            for (int j = 1; j <= 2 * (n - i); j++) System.out.print(" ");
            for (int j = i; j >= 1; j--) print(type, j, symbol);
            System.out.println();
        }
        for (int i = n - 1; i >= 1; i--) {
            for (int j = 1; j <= i; j++) print(type, j, symbol);
            for (int j = 1; j <= 2 * (n - i); j++) System.out.print(" ");
            for (int j = i; j >= 1; j--) print(type, j, symbol);
            System.out.println();
        }
    }

    // ===== HEART =====
    static void heart(int n, int type, char symbol) {
        for (int i = n / 2; i <= n; i += 2) {
            for (int j = 1; j < n - i; j += 2) System.out.print(" ");
            for (int j = 1; j <= i; j++) print(type, j, symbol);
            for (int j = 1; j <= n - i; j++) System.out.print(" ");
            for (int j = 1; j <= i; j++) print(type, j, symbol);
            System.out.println();
        }
        for (int i = n; i >= 1; i--) {
            for (int j = i; j < n; j++) System.out.print(" ");
            for (int j = 1; j <= (2 * i - 1); j++) print(type, j, symbol);
            System.out.println();
        }
    }

    // ===== DIAMOND =====
    static void diamond(int n, int type, char symbol) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n - i; j++)
                System.out.print(" ");
            for (int j = 1; j <= 2 * i - 1; j++)
                print(type, j % 10, symbol);
            System.out.println();
        }
        for (int i = n - 1; i >= 1; i--) {
            for (int j = 1; j <= n - i; j++)
                System.out.print(" ");
            for (int j = 1; j <= 2 * i - 1; j++)
                print(type, j % 10, symbol);
            System.out.println();
        }
    }
    // ===== CIRCLE =====
    static void circle(int r, int type, char symbol) {
        for (int i = 0; i <= 2 * r; i++) {
            for (int j = 0; j <= 4 * r; j++) {
            	double d = Math.sqrt(Math.pow(i - r, 2) + Math.pow((j - 2*r)/2.0, 2));
                if (d > r - 0.5 && d < r + 0.5)
                    print(type, 1, symbol);
                else
                    System.out.print(" ");
            }
            System.out.println();
        }
    }

    
    // ===== SQUARE =====
    static void square(int n, int type, char symbol) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) print(type, j, symbol);
            System.out.println();
        }
    }

    // ===== TRIANGLE =====
    static void triangle(int n, int type, char symbol) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n - i; j++)
                System.out.print(" ");
            for (int j = 1; j <= (2 * i - 1); j++)
                print(type, j % 10, symbol); 
            System.out.println();
        }
    }
    
    // ===== RECTANGLE =====
    static void rectangle(int rows, int cols, int type, char symbol) {
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= cols; j++)
                print(type, j % 10, symbol);
            System.out.println();
        }
    }


    // ===== HEXAGON =====
    static void hexagon(int n, int type, char symbol) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n - i; j++)
           	System.out.print(" ");
            for (int j = 0; j < n + 2 * i; j++) 
            print(type, j+1, symbol);
            System.out.println();
        }
        for (int i = n - 2; i >= 0; i--) {
            for (int j = 0; j < n - i; j++) 
            System.out.print(" ");
            for (int j = 0; j < n + 2 * i; j++) 
            print(type, j+1, symbol);
            System.out.println();
        }
    }
}
