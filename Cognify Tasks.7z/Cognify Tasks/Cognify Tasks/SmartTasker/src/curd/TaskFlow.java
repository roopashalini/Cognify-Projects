package curd;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

class Task {
    int taskId;
    String title;
    String description;
    String category;
    String priority; // High, Medium, Low
    String status;   // Pending, In Progress, Completed, Overdue
    LocalDate dueDate;
    List<String> subtasks;

    Task(int taskId, String title, String description, String category,
         String priority, LocalDate dueDate) {
        this.taskId = taskId;
        this.title = title;
        this.description = description;
        this.category = category;
        this.priority = priority;
        this.status = "Pending";
        this.dueDate = dueDate;
        this.subtasks = new ArrayList<>();
    }
}

public class TaskFlow {

    static List<Task> tasks = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);
    static int taskCounter = 1;
    static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n--- TaskFlow Menu ---");
            System.out.println("1. Create Task");
            System.out.println("2. View All Tasks");
            System.out.println("3. Update Task");
            System.out.println("4. Delete Task");
            System.out.println("5. Dashboard Summary");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = getIntInput();
            switch (choice) {
                case 1: createTask(); break;
                case 2: viewTasks(); break;
                case 3: updateTask(); break;
                case 4: deleteTask(); break;
                case 5: showDashboard(); break;
                case 6: System.out.println("Exiting TaskFlow. Goodbye!"); return;
                default: System.out.println("Invalid choice. Try again.");
            }
        }
    }

    // --- Helper Methods ---

    // Read integer safely
    private static int getIntInput() {
        while (true) {
            try {
                return Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Invalid input, enter a number: ");
            }
        }
    }

    // Read LocalDate safely
    private static LocalDate getDateInput(String prompt) {
        while (true) {
            System.out.print(prompt);
            String dateStr = sc.nextLine();
            try {
                return LocalDate.parse(dateStr, formatter);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format. Use dd-MM-yyyy.");
            }
        }
    }

    // --- CRUD Methods ---

    private static void createTask() {
        System.out.print("Enter Title: ");
        String title = sc.nextLine();
        System.out.print("Enter Description: ");
        String desc = sc.nextLine();
        System.out.print("Enter Category (Work/Personal/Study): ");
        String category = sc.nextLine();
        System.out.print("Enter Priority (High/Medium/Low): ");
        String priority = sc.nextLine();
        LocalDate dueDate = getDateInput("Enter Due Date (dd-MM-yyyy): ");

        Task task = new Task(taskCounter++, title, desc, category, priority, dueDate);

        // Add subtasks
        System.out.print("Add subtasks? (Y/N): ");
        String sub = sc.nextLine();
        while (sub.equalsIgnoreCase("Y")) {
            System.out.print("Enter Subtask: ");
            task.subtasks.add(sc.nextLine());
            System.out.print("Add another subtask? (Y/N): ");
            sub = sc.nextLine();
        }

        tasks.add(task);
        System.out.println("Task created successfully with ID: " + task.taskId);
    }

    private static void viewTasks() {
        if (tasks.isEmpty()) {
            System.out.println("No tasks available.");
            return;
        }
        System.out.println("\n--- All Tasks ---");
        for (Task t : tasks) {
            // Update status if overdue
            if (t.status.equals("Pending") && t.dueDate.isBefore(LocalDate.now())) {
                t.status = "Overdue";
            }
            System.out.println("ID: " + t.taskId + " | Title: " + t.title + " | Status: " + t.status);
            System.out.println("Category: " + t.category + " | Priority: " + t.priority + " | Due: " + t.dueDate.format(formatter));
            System.out.println("Description: " + t.description);
            if (!t.subtasks.isEmpty()) {
                System.out.println("Subtasks: ");
                for (int i = 0; i < t.subtasks.size(); i++) {
                    System.out.println("  " + (i + 1) + ". " + t.subtasks.get(i));
                }
            }
            System.out.println("-----------------------------");
        }
    }

    private static Task findTaskById(int id) {
        for (Task t : tasks) {
            if (t.taskId == id) return t;
        }
        return null;
    }

    private static void updateTask() {
        System.out.print("Enter Task ID to update: ");
        int id = getIntInput();
        Task t = findTaskById(id);
        if (t == null) {
            System.out.println("Task not found.");
            return;
        }

        System.out.println("Updating Task: " + t.title);
        System.out.println("1. Update Title");
        System.out.println("2. Update Description");
        System.out.println("3. Update Category");
        System.out.println("4. Update Priority");
        System.out.println("5. Update Status");
        System.out.println("6. Update Due Date");
        System.out.println("7. Add Subtask");
        System.out.print("Enter your choice: ");
        int choice = getIntInput();

        switch (choice) {
            case 1: System.out.print("New Title: "); t.title = sc.nextLine(); break;
            case 2: System.out.print("New Description: "); t.description = sc.nextLine(); break;
            case 3: System.out.print("New Category: "); t.category = sc.nextLine(); break;
            case 4: System.out.print("New Priority: "); t.priority = sc.nextLine(); break;
            case 5: System.out.print("New Status (Pending/In Progress/Completed/Overdue): "); t.status = sc.nextLine(); break;
            case 6: t.dueDate = getDateInput("New Due Date (dd-MM-yyyy): "); break;
            case 7: 
                System.out.print("Enter Subtask: "); 
                t.subtasks.add(sc.nextLine()); 
                break;
            default: System.out.println("Invalid choice."); return;
        }
        System.out.println("Task updated successfully!");
    }

    private static void deleteTask() {
        System.out.print("Enter Task ID to delete: ");
        int id = getIntInput();
        Task t = findTaskById(id);
        if (t == null) {
            System.out.println("Task not found.");
            return;
        }
        System.out.print("Are you sure you want to delete this task? (Y/N): ");
        String confirm = sc.nextLine();
        if (confirm.equalsIgnoreCase("Y")) {
            tasks.remove(t);
            System.out.println("Task deleted successfully.");
        } else {
            System.out.println("Delete cancelled.");
        }
    }

    private static void showDashboard() {
        int total = tasks.size();
        int pending = 0, completed = 0, overdue = 0, high = 0, medium = 0, low = 0;

        for (Task t : tasks) {
            if (t.status.equals("Pending")) pending++;
            else if (t.status.equals("Completed")) completed++;
            else if (t.status.equals("Overdue")) overdue++;

            if (t.priority.equalsIgnoreCase("High")) high++;
            else if (t.priority.equalsIgnoreCase("Medium")) medium++;
            else if (t.priority.equalsIgnoreCase("Low")) low++;
        }

        System.out.println("\n--- TaskFlow Dashboard ---");
        System.out.println("Total Tasks: " + total);
        System.out.println("Pending: " + pending);
        System.out.println("Completed: " + completed);
        System.out.println("Overdue: " + overdue);
        System.out.println("High Priority: " + high);
        System.out.println("Medium Priority: " + medium);
        System.out.println("Low Priority: " + low);
        System.out.println("----------------------------");
    }
}

