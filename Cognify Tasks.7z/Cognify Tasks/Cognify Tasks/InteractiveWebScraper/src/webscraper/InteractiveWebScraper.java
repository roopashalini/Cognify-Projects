package webscraper;


import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class InteractiveWebScraper {

    // Scrape headings (h1, h2, h3) using JSoup
    public static List<String> scrapeHeadings(String url) throws IOException {
        List<String> headings = new ArrayList<>();
        Document doc = Jsoup.connect(url).get();
        Elements elements = doc.select("h1, h2, h3");

        for (Element e : elements) {
            headings.add(e.text());
        }
        return headings;
    }

    // Scrape links using JSoup
    public static List<String> scrapeLinks(String url) throws IOException {
        List<String> links = new ArrayList<>();
        Document doc = Jsoup.connect(url).get();
        Elements elements = doc.select("a[href]");

        for (Element e : elements) {
            links.add(e.text() + " -> " + e.attr("href"));
        }
        return links;
    }

    // Scrape multiple pages (headings only)
    public static List<String> scrapeMultiplePages(List<String> urls) throws IOException {
        List<String> result = new ArrayList<>();
        for (String url : urls) {
            result.add("---- Data from: " + url + " ----");
            result.addAll(scrapeHeadings(url));
        }
        return result;
    }

    // Save data to a text file
    public static void saveToTextFile(List<String> data, String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            for (String line : data) {
                writer.write(line + "\n");
            }
            System.out.println("Data saved to " + filename);
        } catch (IOException e) {
            System.out.println("Error saving file");
        }
    }

    // Export data to CSV
    public static void exportToCSV(List<String> data, String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            writer.write("Scraped Data\n");
            for (String line : data) {
                writer.write("\"" + line + "\"\n");
            }
            System.out.println("Data exported to CSV: " + filename);
        } catch (IOException e) {
            System.out.println("Error exporting CSV");
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== INTERACTIVE WEB SCRAPER =====");
            System.out.println("1. Scrape Headings");
            System.out.println("2. Scrape Links");
            System.out.println("3. Scrape Multiple Pages (Headings)");
            System.out.println("4. Exit");

            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            try {
                if (choice == 1) {
                    System.out.print("Enter URL: ");
                    String url = sc.nextLine();
                    List<String> data = scrapeHeadings(url);
                    data.forEach(System.out::println);
                    saveToTextFile(data, "headings.txt");
                    exportToCSV(data, "headings.csv");

                } else if (choice == 2) {
                    System.out.print("Enter URL: ");
                    String url = sc.nextLine();
                    List<String> data = scrapeLinks(url);
                    data.forEach(System.out::println);
                    saveToTextFile(data, "links.txt");
                    exportToCSV(data, "links.csv");

                } else if (choice == 3) {
                    System.out.print("How many URLs: ");
                    int n = sc.nextInt();
                    sc.nextLine(); // consume newline
                    List<String> urls = new ArrayList<>();
                    for (int i = 0; i < n; i++) {
                        System.out.print("Enter URL " + (i + 1) + ": ");
                        urls.add(sc.nextLine());
                    }
                    List<String> data = scrapeMultiplePages(urls);
                    data.forEach(System.out::println);
                    saveToTextFile(data, "multipage.txt");
                    exportToCSV(data, "multipage.csv");

                } else if (choice == 4) {
                    System.out.println("Exiting...");
                    break;

                } else {
                    System.out.println("Invalid choice");
                }

            } catch (IOException e) {
                System.out.println("Error occurred while fetching data. Check the URL or internet connection.");
            }
        }

        sc.close();
    }
}