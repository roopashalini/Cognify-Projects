package game;
import java.util.Scanner;
public class WizardMindGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Welcome, brave adventurer!");
		System.out.println("You have entered the Wizard’s Tower of Numeria...");
		System.out.println("A mysterious wizard appears before you.");
		System.out.println();
		System.out.println("\"Follow my instructions,\" says the Wizard,");
		System.out.println("\"and I shall read your mind!\"");
		System.out.print("Are you ready to begin? (yes/no): ");
		String choice = sc.nextLine();
		if (!choice.equalsIgnoreCase("yes")) {
		    System.out.println("Wizard: Come back when you are ready, adventurer!");
		    return; // ends the game
		}
		System.out.println();
		System.out.println("Wizard: Think of a number between 1 and 10.");
		System.out.println("Do NOT tell me the number.");
		System.out.println();
		System.out.println("Now follow my magic carefully:");
		System.out.println("1. Multiply your number by 2");
		System.out.println("2. Add 4 to the result");
		System.out.println("3. Divide the result by 2");
		System.out.println("4. Subtract your original number");
		System.out.println();
		System.out.print("Press Enter when you are done...");
		sc.nextLine(); // wait for user
		System.out.println();
		System.out.println("The Wizard closes his eyes...");
		System.out.println("Murmurs ancient spells...");
		System.out.println();
		System.out.println("Wizard: I see the number clearly now!");
		System.out.println("Wizard: The final number in your mind is...");
		System.out.println();
		System.out.println("✨✨✨ 2 ✨✨✨");
		System.out.println();
		System.out.println("Wizard: You have passed my test!");
		System.out.println("Choose your reward:");
		System.out.println("1. Golden Key");
		System.out.println("2. Magic Potion");
		System.out.println("3. Spell Scroll");
		System.out.print("Enter your choice (1/2/3): ");

		int reward = sc.nextInt();
		
		if (reward == 1) {
		    System.out.println("You receive a Golden Key that opens hidden treasures!");
		} else if (reward == 2) {
		    System.out.println("You drink the Magic Potion and gain infinite wisdom!");
		} else if (reward == 3) {
		    System.out.println("The Spell Scroll glows. You now control numbers!");
		} else {
		    System.out.println("Wizard: Hmm... that choice does not exist!");
		}
		System.out.println();
		System.out.println("Thank you for playing The Wizard’s Mind Game!");
		System.out.println("Game Over.");
		sc.close();

	}

}
