/**
 * 
 */
/**
 * 
 */
module TextBasedAdventureGame {
}